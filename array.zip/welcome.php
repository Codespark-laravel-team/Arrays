    <?php
    session_start();
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Register</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

     
        <link rel="stylesheet" type="text/css" media="screen" href="assets/css/bootstrap.min.css" />
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.js"></script>


        
    </head>
    <body>
 <!-- Opening the container div -->
    <div class="container">
<!-- row -->
    <div class="row">
      <!-- col-md-6 opening -->
    <div class="col-md-6 offset-md-3">
<h1>Welcome Page</h1>
<div class="jumbotron">
    <h3>Thank you for signing up</h3>

</div>

    </div>
    <!-- closing row -->
    </div>
    <!-- closing the container div -->
    </div>
    </body>
    </html>

